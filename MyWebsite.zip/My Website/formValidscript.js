function validate(){
    var name=document.getElementById('name').value;
    var sname=document.getElementById('sname').value;
    var email=document.getElementById('email').value;
    var phone=document.getElementById('phone').value;

    
    var nameLength=name.length;
    var phoneLength=phone.length;
    var letters = /^[A-Za-z]+$/;



    if(!(name.match(letters)) || nameLength<5 || nameLength>15)
    {
        alert("Name cannot be empty or number or less than 3 or greater than 15");
        document.getElementById('name').focus();
    }
    
    else if(!(sname.match(letters)) || nameLength<5 || nameLength>15)
    {
        alert("Name cannot be empty or number or less than 3 or greater than 15");
        document.getElementById('sname').focus();
    }
    
   
    else if(isNaN(phone) || phoneLength!=10 )
    {
        alert("Phone number cannot be null or string and should be 10 digits");
        document.getElementById('phone').focus();
    }
 
    else if(nameList.indexOf(name) == -1 )
    {
        document.getElementById("print").innerHTML="Welcome "+name+"<br>"+email+"<br> "+phone;
    }
    
    else
    {
        document.getElementById("myform").submit();
       
    }
    
}